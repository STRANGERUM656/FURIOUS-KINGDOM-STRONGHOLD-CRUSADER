# Abbot FINAL BOSS - Guida

## File nello zip
- `Abbot_AIC.json`: solo Abbot, potenziato al massimo (economia, reclutamento, assedi, attacchi).
- `FAPLZ_5_5_2_FINAL_BOSS.json`: il tuo file con tutte le AI, Abbot sostituito con la versione FINAL BOSS.

Usa uno dei due, non entrambi insieme.

## Installazione
1. Copia il file `.json` nella cartella AIC del gioco (il percorso dipende dalla versione di Stronghold Crusader).
2. In una partita skirmish seleziona il file AIC e scegli Abbot come avversario.
3. Imposta il no-rush a 10 minuti nelle opzioni della partita. Dopo quel tempo Abbot attacca il giocatore umano.

## Castello consigliato (da disegnare con l'editor di castelli AI)
Il file `.json` controlla il comportamento, non la forma del castello. Per mura rinforzate disegna questo schema:

```
 T = torre   W = mura   M = fossato   P = pece   K = keep
 A = arcieri/balestrieri   F = lanciafiamme

 T W W T W W T W W T W W T
 W  A A A A A A A A A A  W
 T  A                 A  T
 W  A   W W T W W     A  W
 W  A   W  F K F W    A  W
 T  A   W W T W W     A  T
 W  A                 A  W
 W  A A A A A A A A A A  W
 T W W T W W T W W T W W T
 M M M M M M M M M M M M M M
```

Regole del disegno:
1. Doppia cinta: mura esterne alte con torri ogni 6-8 caselle, mura interne attorno al keep.
2. Fossato continuo all'esterno, con pozzi di pece sul lato dove arriva il nemico.
3. Balestrieri e arcieri sulle mura esterne, lanciafiamme ai varchi e vicino al keep.
4. Un solo ingresso, con torri doppie ai lati e la casermia subito dietro.
5. Cave, miniere e fattorie dentro la seconda cinta, così l'economia non viene raggiunta.

## Cosa fa il file AI
- Compra cibo ed equipaggiamento al massimo e non vende nulla.
- Difesa al massimo: 260 sulle mura, 8 pattuglie di mura, 4 esterne, fossati da 60 unità.
- Assedi con trabucchi, torri, arieti, balliste e scudi.
- Fino a 40 assassini, 150 balestrieri di supporto, 80 monaci e 5 gruppi d'attacco.
- Bersaglio: il giocatore umano.
